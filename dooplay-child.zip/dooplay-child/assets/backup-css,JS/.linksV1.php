<?php
/**
 * links.php (Upgraded)
 * - Netflix-style SVG server icon
 * - Emoji flags (modern flat style)
 * - Hover animations, skeleton loading
 * - AJAX tabs (client-side switching)
 *
 * Drop into your theme (replace existing links.php).
 */

if (!defined('ABSPATH')) { exit; }

/* ---------------------------
   Helper: parse DooPlay table
   --------------------------- */
function nf_get_links_from_dooplay($post_id, $type_label, $mode) {
    if (!class_exists('DooLinks') || !method_exists('DooLinks', 'tablelist_front')) {
        return [];
    }

    ob_start();
    DooLinks::tablelist_front($post_id, $type_label, $mode);
    $html = ob_get_clean();

    $rows = [];
    if (!preg_match_all('/<tr[^>]*>(.*?)<\/tr>/is', $html, $tr_matches)) {
        return $rows;
    }

    foreach ($tr_matches[1] as $tr_content) {
        if (!preg_match_all('/<td[^>]*>(.*?)<\/td>/is', $tr_content, $td_matches)) continue;
        $tds = $td_matches[1];
        if (count($tds) < 4) continue;

        // td0 => server/icon/link, td1 => quality, td2 => language, td3 => size
        $td0 = $tds[0];

        // favicon src, if any
        $favicon_src = null;
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $td0, $m_img)) {
            $favicon_src = $m_img[1];
        }

        // server name extraction
        $server_name = '';
        if ($favicon_src && preg_match('/(?:domain|d)=([^&"\']+)/i', $favicon_src, $m_domain)) {
            $server_name = urldecode($m_domain[1]);
        }
        if (empty($server_name)) {
            $tmp = preg_replace('/<img[^>]*>/i', '', $td0);
            $tmp = preg_replace('/<a[^>]*>(.*?)<\/a>/is', '$1', $tmp);
            $tmp = strip_tags($tmp);
            $tmp = trim(html_entity_decode($tmp));
            if ($tmp !== '') $server_name = $tmp;
        }
        if (empty($server_name)) $server_name = 'Unknown Server';

        // Extract anchors for real links
        $real_href = '#';
        $label = 'Download';
        if (preg_match_all('/<a([^>]*)>(.*?)<\/a>/is', $tr_content, $a_matches, PREG_SET_ORDER)) {
            $found = false;
            foreach ($a_matches as $am) {
                $attrs = $am[1];
                $inner = trim(strip_tags($am[2]));
                if ($inner !== '') $label = html_entity_decode($inner);

                // check attributes in common order
                $attrKeys = ['data-l','data-link','data-href','data-url','href'];
                foreach ($attrKeys as $k) {
                    $pattern = '/'.$k.'=["\']([^"\']+)["\']/i';
                    if (preg_match($pattern, $attrs, $m)) {
                        $candidate = $m[1];
                        // prefer http(s) or non-#
                        if ($candidate && ($candidate === '#' ? false : true)) {
                            // prefer absolute links; accept relative if not '#'
                            $real_href = $candidate;
                            $found = true;
                            break 2;
                        }
                    }
                }
            }
            // fallback to first anchor href if nothing matched
            if (!$found && isset($a_matches[0])) {
                if (preg_match('/href=["\']([^"\']+)["\']/i', $a_matches[0][1], $mhref)) {
                    $real_href = $mhref[1];
                }
            }
        }

        // quality, language, size
        $quality = isset($tds[1]) ? trim(strip_tags($tds[1])) : '';
        $language = isset($tds[2]) ? trim(strip_tags($tds[2])) : '';
        $size = isset($tds[3]) ? trim(html_entity_decode(strip_tags($tds[3]))) : '';

        $rows[] = [
            'server' => $server_name,
            'server_icon' => $favicon_src,
            'quality' => $quality,
            'lang' => $language,
            'size' => $size,
            'url' => $real_href,
            'label' => $label,
        ];
    }
    return $rows;
}

/* ---------------------------
   Helper: language => emoji flag
   (Modern flat emoji flags)
   --------------------------- */
function nf_lang_to_flag($lang) {
    if (!$lang) return '';
    $l = strtolower($lang);
    // simple mapping; add more as needed
    $map = [
        'english' => '🇺🇸',
        'en'      => '🇺🇸',
        'hindi'   => '🇮🇳',
        'hi'      => '🇮🇳',
        'spanish' => '🇪🇸',
        'es'      => '🇪🇸',
        'french'  => '🇫🇷',
        'fr'      => '🇫🇷',
        'german'  => '🇩🇪',
        'de'      => '🇩🇪',
        'portuguese' => '🇵🇹',
        'pt'      => '🇵🇹',
        'italian' => '🇮🇹',
        'it'      => '🇮🇹',
        'korean'  => '🇰🇷',
        'kr'      => '🇰🇷',
        'japanese'=> '🇯🇵',
        'jp'      => '🇯🇵',
        'arabic'  => '🇸🇦',
        'ru'      => '🇷🇺',
        'russian' => '🇷🇺',
        'turkish' => '🇹🇷',
        'tr'      => '🇹🇷',
        'urdu'    => '🇵🇰',
    ];
    foreach ($map as $key => $flag) {
        if (strpos($l, $key) !== false) return $flag;
    }
    // default: return uppercase short form (e.g., EN)
    $short = strtoupper(substr($lang,0,2));
    return $short;
}
?>

<!-- INLINE CSS: layout, SVG icon, skeleton, hover, tabs -->
<style type="text/css">
/* Layout */
.netflinks-wrapper { width:100%; box-sizing:border-box; margin-bottom:28px; color:#e5e5e5; font-family: Arial, Helvetica, sans-serif; }
.netflinks-tabbar { display:flex; gap:10px; align-items:center; margin-bottom:14px; flex-wrap:wrap; }
.netflinks-tab { cursor:pointer; padding:8px 14px; border-radius:8px; background:#0d0d0d; border:1px solid rgba(255,255,255,0.04); color:#dcdcdc; text-decoration:none; }
.netflinks-tab.active { background:#e50914; color:#fff; border-color:#e50914; box-shadow:0 6px 18px rgba(229,9,20,0.12); }

/* Grid & Card */
.netflinks-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(240px,1fr)); gap:16px; transition:opacity .18s ease; }
.netflinks-card { background:#141414;padding:14px;border-radius:10px;border:1px solid rgba(255,255,255,0.04); display:flex;flex-direction:column; gap:8px; transform:translateY(0); transition:transform .16s ease, box-shadow .16s ease; }
.netflinks-card:hover { transform:translateY(-6px); box-shadow:0 18px 42px rgba(0,0,0,0.6); border-color:#e50914; }

/* quality */
.netflinks-quality { font-weight:700; font-size:1.03rem; color:#fff; }

/* server */
.netflinks-server { display:flex; align-items:center; gap:10px; background:#000;padding:8px 10px;border-radius:8px;border:1px solid rgba(255,255,255,0.02); color:#fff; font-weight:600; }
.netflinks-server img { width:18px;height:18px;object-fit:contain;border-radius:3px; }

/* meta, size */
.netflinks-meta { color:#cfcfcf; font-size:.95rem; }
.netflinks-size { font-size:1rem; color:#e5e5e5; }

/* actions */
.netflinks-actions { display:flex; gap:10px; margin-top:6px; }
.netflinks-actions a { flex:1;padding:10px;border-radius:8px;border:1px solid #e50914;background:transparent;color:#e50914;font-weight:700;text-decoration:none;text-transform:uppercase;text-align:center; }
.netflinks-actions a:hover { background:#e50914;color:#fff; }

/* skeleton placeholders */
.skeleton-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(240px,1fr)); gap:16px; }
.skeleton { background:linear-gradient(90deg, #1a1a1a 0%, #232323 50%, #1a1a1a 100%); background-size:200% 100%; animation:skeleton-shimmer 1.2s linear infinite; border-radius:10px; padding:14px; min-height:120px; }
@keyframes skeleton-shimmer { 0% { background-position:200% 0 } 100% { background-position:-200% 0 } }

/* responsive */
@media (max-width:480px) {
    .netflinks-tabbar { gap:8px; }
    .netflinks-actions a { padding:8px; font-size:.95rem; }
}
</style>

<!-- SVG server icon (Netflix style) placed once so we can reuse inline when needed -->
<svg style="display:none;" xmlns="http://www.w3.org/2000/svg">
    <symbol id="nf-server" viewBox="0 0 24 24">
        <!-- simple minimalist icon -->
        <rect x="2" y="5" width="20" height="14" rx="2" ry="2" fill="#e50914"></rect>
        <rect x="5" y="8" width="6" height="2" rx="1" ry="1" fill="#fff"></rect>
        <rect x="5" y="12" width="10" height="2" rx="1" ry="1" fill="#fff"></rect>
    </symbol>
</svg>

<div class="netflinks-wrapper">
    <!-- TAB BAR -->
    <div class="netflinks-tabbar" role="tablist">
        <button class="netflinks-tab active" data-mode="download" role="tab" aria-selected="true">Download</button>
        <button class="netflinks-tab" data-mode="torrent" role="tab" aria-selected="false">Torrent</button>
        <button class="netflinks-tab" data-mode="videos" role="tab" aria-selected="false">Watch Online</button>
    </div>

    <!-- Skeleton placeholders (shown briefly while JS reveals content) -->
    <div id="netflinks-skeleton" class="skeleton-grid" aria-hidden="false">
        <div class="skeleton"></div>
        <div class="skeleton"></div>
        <div class="skeleton"></div>
        <div class="skeleton"></div>
    </div>

    <!-- Content containers (one per type) -->
    <?php
    $post_id = isset($post->ID) ? $post->ID : (function_exists('get_the_ID') ? get_the_ID() : 0);
    $types = [
        ['label' => __d('Download'), 'mode' => 'download', 'title' => 'Download'],
        ['label' => __d('Torrent'),  'mode' => 'torrent',  'title' => 'Torrent'],
        ['label' => __d('Watch online'), 'mode' => 'videos', 'title' => 'Watch Online'],
    ];

    // prepare datasets
    $all_data = [];
    foreach ($types as $t) {
        $rows = [];
        // only parse if links exist (doo_here_type_links)
        if (function_exists('doo_here_type_links') && !doo_here_type_links($post_id, $t['label'])) {
            $rows = [];
        } else {
            $rows = nf_get_links_from_dooplay($post_id, $t['label'], $t['mode']);
        }
        $all_data[$t['mode']] = $rows;
    }

    // output grids (hidden by JS except active)
    foreach ($types as $t):
        $mode = $t['mode'];
        $rows = isset($all_data[$mode]) ? $all_data[$mode] : [];
        // JSON-encode rows for client-side usage too (used by JS when switching)
        $json_rows = json_encode($rows);
    ?>
        <div class="netflinks-grid" data-mode="<?php echo esc_attr($mode); ?>" data-rows='<?php echo $json_rows; ?>' style="display:<?php echo $mode === 'download' ? 'grid' : 'none'; ?>;">
            <?php
            if (empty($rows)) {
                echo '<div style="grid-column:1/-1;color:#cfcfcf;padding:12px;background:#0f0f0f;border-radius:8px;">' . __('No links available') . '</div>';
            } else {
                foreach ($rows as $r):
                    $server = isset($r['server']) ? $r['server'] : 'Unknown Server';
                    $icon = isset($r['server_icon']) && !empty($r['server_icon']) ? esc_url($r['server_icon']) : '';
                    $quality = isset($r['quality']) ? $r['quality'] : '';
                    $lang = isset($r['lang']) ? $r['lang'] : '';
                    $size = isset($r['size']) ? $r['size'] : '';
                    $url = isset($r['url']) ? $r['url'] : '#';
                    $label = isset($r['label']) ? $r['label'] : __('Download');
                    // flag emoji
                    $flag = nf_lang_to_flag($lang);
            ?>
                <article class="netflinks-card" role="article" aria-label="<?php echo esc_attr($server . ' ' . $quality); ?>">
                    <?php if ($quality): ?><div class="netflinks-quality"><?php echo esc_html($quality); ?></div><?php endif; ?>

                    <div class="netflinks-server">
                        <?php if ($icon): ?>
                            <img src="<?php echo $icon; ?>" alt="<?php echo esc_attr($server); ?>">
                        <?php else: ?>
                            <svg width="18" height="18" aria-hidden="true"><use xlink:href="#nf-server"></use></svg>
                        <?php endif; ?>
                        <span style="flex:1;"><?php echo esc_html($server); ?></span>
                        <?php if ($flag): ?>
                            <span aria-hidden="true" style="font-size:16px;"><?php echo $flag; ?></span>
                        <?php elseif ($lang): ?>
                            <span style="color:#bfbfbf;font-weight:500;"><?php echo esc_html($lang); ?></span>
                        <?php endif; ?>
                    </div>

                    <?php if ($size): ?><div class="netflinks-meta"><span class="netflinks-size">📦 <?php echo esc_html($size); ?></span></div><?php endif; ?>

                    <div class="netflinks-actions">
                        <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($label); ?></a>
                    </div>
                </article>
            <?php
                endforeach;
            }
            ?>
        </div>
    <?php endforeach; ?>

    <!-- Uploader form kept at bottom (inline styled) -->
<?php
if (is_user_logged_in() && class_exists('DooLinks') && method_exists('DooLinks','front_publisher_role') && DooLinks::front_publisher_role() === true):
?>
    <h2 style="margin-top:18px;color:#e5e5e5;border-left:4px solid #e50914;padding-left:12px;"><?php _d('Submit Links'); ?></h2>
    <div style="background:#141414;padding:16px;border-radius:10px;border:1px solid rgba(255,255,255,0.04);margin-top:10px;">
        <div id="resultado_link_form"></div>
        <form id="doopostlinks" enctype="application/json" style="display:block;">
            <table style="width:100%;border-collapse:collapse;color:#fff;">
                <thead>
                    <tr>
                        <th style="text-align:left;padding:6px 8px;"><?php _d('Type'); ?></th>
                        <th style="text-align:left;padding:6px 8px;"><?php _d('URL'); ?></th>
                        <th style="text-align:left;padding:6px 8px;"><?php _d('Quality'); ?></th>
                        <th style="text-align:left;padding:6px 8px;"><?php _d('Language'); ?></th>
                        <th style="text-align:left;padding:6px 8px;"><?php _d('File size'); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody class="tbody">
                    <tr class="row first_tr">
                        <td style="padding:6px 8px;">
                            <select name="type" style="padding:6px;border-radius:6px;background:#0b0b0b;border:1px solid rgba(255,255,255,0.03);color:#fff;">
                                <?php foreach( DooLinks::types() as $type) { echo "<option>" . esc_html($type) . "</option>"; } ?>
                            </select>
                        </td>
                        <td style="padding:6px 8px;">
                            <input name="url" type="text" class="url" placeholder="http://" style="width:100%;padding:8px;border-radius:6px;background:#0b0b0b;border:1px solid rgba(255,255,255,0.03);color:#fff;">
                        </td>
                        <td style="padding:6px 8px;">
                            <select name="quality" style="padding:6px;border-radius:6px;background:#0b0b0b;border:1px solid rgba(255,255,255,0.03);color:#fff;">
                                <?php foreach( DooLinks::resolutions() as $resolution) { echo "<option>" . esc_html($resolution) . "</option>"; } ?>
                            </select>
                        </td>
                        <td style="padding:6px 8px;">
                            <select name="lang" style="padding:6px;border-radius:6px;background:#0b0b0b;border:1px solid rgba(255,255,255,0.03);color:#fff;">
                                <?php foreach( DooLinks::langs() as $lang_item) { echo "<option>" . esc_html($lang_item) . "</option>"; } ?>
                            </select>
                        </td>
                        <td style="padding:6px 8px;">
                            <input name="size" type="text" class="size" style="padding:8px;border-radius:6px;background:#0b0b0b;border:1px solid rgba(255,255,255,0.03);color:#fff;">
                        </td>
                        <td style="padding:6px 8px;"><a data-repeater-delete class="remove_row" style="color:#e50914;text-decoration:none;cursor:pointer;">X</a></td>
                    </tr>
                </tbody>
            </table>

            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;">
                <a data-repeater-create id="add_row" class="add_row" style="background:#111;padding:10px 12px;border-radius:8px;color:#fff;text-decoration:none;"><?php _d('+ Add row'); ?></a>
                <input type="submit" value="<?php _d('Send link(s)'); ?>" style="background:#e50914;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer;">
            </div>

            <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id); ?>">
            <input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('doolinks')); ?>">
            <input type="hidden" name="action" value="doopostlinks">
        </form>
    </div>
<?php endif; ?>


<!-- JS: Tabs, skeleton reveal, client-side grid switch -->
<script type="text/javascript">
(function(){
    // helper
    function $q(sel, ctx){ return (ctx || document).querySelector(sel); }
    function $qa(sel, ctx){ return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

    var tabs = $qa('.netflinks-tab');
    var skeleton = $q('#netflinks-skeleton');
    var grids = $qa('.netflinks-grid');

    // Show skeleton then reveal content to create smooth effect
    function revealAfterDelay() {
        // show skeleton for 320ms then hide
        if (!skeleton) return;
        skeleton.style.display = 'grid';
        // hide grids temporarily
        grids.forEach(function(g){ g.style.opacity = '0'; });
        setTimeout(function(){
            skeleton.style.display = 'none';
            grids.forEach(function(g){
                g.style.opacity = '1';
                // fade-in
                g.style.transition = 'opacity .28s ease';
            });
        }, 320);
    }
    revealAfterDelay();

    // Tab click handler: switch grids (client-side only)
    tabs.forEach(function(tab){
        tab.addEventListener('click', function(){
            var mode = tab.getAttribute('data-mode');
            // set active class
            tabs.forEach(function(t){ t.classList.remove('active'); t.setAttribute('aria-selected','false'); });
            tab.classList.add('active'); tab.setAttribute('aria-selected','true');

            // find corresponding grid; show it, hide others
            grids.forEach(function(g){
                if (g.getAttribute('data-mode') === mode) {
                    g.style.display = 'grid';
                    // If grid is empty and has data-rows, we can populate (no server call required)
                    try {
                        var rows = JSON.parse(g.getAttribute('data-rows') || '[]');
                        if (rows && rows.length && g.children.length === 0) {
                            // populate cards (safety: minimal)
                            rows.forEach(function(r){
                                var article = document.createElement('article');
                                article.className = 'netflinks-card';
                                var html = '';
                                if (r.quality) html += '<div class="netflinks-quality">'+(r.quality||'')+'</div>';
                                html += '<div class="netflinks-server">';
                                if (r.server_icon) {
                                    html += '<img src="'+r.server_icon+'" alt="'+(r.server||'')+'">';
                                } else {
                                    html += '<svg width="18" height="18" aria-hidden="true"><use xlink:href=\"#nf-server\"></use></svg>';
                                }
                                html += '<span style="flex:1;">'+(r.server||'')+'</span>';
                                if (r.lang) html += '<span style="font-size:16px;">' + (function(){ return (function mapLang(l){ if(!l) return ''; var L=l.toLowerCase(); if(L.indexOf('english')!==-1||L==='en') return '🇺🇸'; if(L.indexOf('hindi')!==-1||L==='hi') return '🇮🇳'; if(L.indexOf('spanish')!==-1||L==='es') return '🇪🇸'; if(L.indexOf('french')!==-1||L==='fr') return '🇫🇷'; if(L.indexOf('german')!==-1||L==='de') return '🇩🇪'; return l; })(r.lang); })() + '</span>';
                                html += '</div>';
                                if (r.size) html += '<div class="netflinks-meta"><span class="netflinks-size">📦 '+(r.size||'')+'</span></div>';
                                html += '<div class="netflinks-actions"><a href="'+(r.url||'#')+'" target="_blank" rel="noopener noreferrer">'+(r.label||'Download')+'</a></div>';
                                article.innerHTML = html;
                                g.appendChild(article);
                            });
                        }
                    } catch(e){}
                    g.style.opacity = '1';
                } else {
                    g.style.display = 'none';
                }
            });
        });
    });

    // Accessibility: allow keyboard navigation of tabs
    tabs.forEach(function(t){
        t.addEventListener('keydown', function(e){
            var idx = tabs.indexOf(t);
            if (e.key === 'ArrowRight') {
                var next = tabs[(idx+1)%tabs.length];
                next.focus(); next.click();
            } else if (e.key === 'ArrowLeft') {
                var prev = tabs[(idx-1+tabs.length)%tabs.length];
                prev.focus(); prev.click();
            }
        });
    });

})();
</script>

</div> <!-- wrapper end -->
