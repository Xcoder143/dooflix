<?php
/*
* -------------------------------------------------------------------------------------
* @author: Doothemes
* @author URI: https://doothemes.com/
* -------------------------------------------------------------------------------------
*/

$classlinks = new DooLinks;
$postmeta = doo_postmeta_movies($post->ID);

// Meta
$trailer = doo_isset($postmeta,'youtube_id');
$pviews  = doo_isset($postmeta,'dt_views_count');
$player  = maybe_unserialize( doo_isset($postmeta,'players') );
$images  = doo_isset($postmeta,'imagenes');

$tviews  = ($pviews) ? sprintf(__d('%s Views'), $pviews) : __d('0 Views');

// Image logic
$dynamicbg  = dbmovies_get_rand_image($images);
$poster_url = dbmovies_get_poster($post->ID,'large');

if (empty($dynamicbg)) $dynamicbg = $poster_url;

// Options
$player_ads = doo_compose_ad('_dooplay_adplayer');
$player_wht = dooplay_get_option('playsize','regular');

/* =============================
   Helper Functions (Safe Mode)
============================= */

if (!function_exists('resolve_player_src')) {
    function resolve_player_src($srv){
        if (is_array($srv)){
            foreach(['iframe','src','url','link','embed'] as $k){
                if (!empty($srv[$k])){
                    $val = $srv[$k];
                    if (strpos($val,'<iframe') !== false){
                        if (preg_match('/src=["\']([^"\']+)["\']/', $val, $m)) return esc_url_raw($m[1]);
                    }
                    if (filter_var($val, FILTER_VALIDATE_URL)) return esc_url_raw($val);
                    return esc_url_raw($val);
                }
            }
        } else {
            if (strpos($srv,'<iframe') !== false){
                if (preg_match('/src=["\']([^"\']+)["\']/', $srv, $m)) return esc_url_raw($m[1]);
            }
            if (filter_var($srv, FILTER_VALIDATE_URL)) return esc_url_raw($srv);
        }
        return '';
    }
}

if (!function_exists('ytembed')) {
    function ytembed($id){
        if (empty($id)) return '';
        if (strpos($id,'youtu') !== false){
            if (preg_match('/v=([^&]+)/',$id,$m)) return "https://www.youtube.com/embed/".$m[1];
            if (preg_match('#youtu\.be/([^?\s]+)#',$id,$m)) return "https://www.youtube.com/embed/".$m[1];
        }
        return "https://www.youtube.com/embed/".rawurlencode($id);
    }
}

$trailer_embed = (!empty($trailer)) ? ytembed($trailer) : '';

?>
<style>
/* --- GLOBAL --- */
.dtsingle{width:100%;max-width:100%;background:#141414;color:#fff;font-family:'Helvetica Neue',Arial,sans-serif; overflow-x: hidden;}

/* --- HERO SECTION --- */
.hero {
    width: 100%;
    height: 85vh;
    background-size: cover;
    background-position: center top;
    position: relative;
    display: flex;
    align-items: center;
}
.hero::before {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(to top, #141414 10%, transparent 50%);
    z-index: 1;
}
.hero::after {
    content: "";
    position: absolute;
    inset: 0;
    background: linear-gradient(to right, rgba(0,0,0,0.8) 0%, transparent 60%);
    z-index: 1;
}

.hero-content {
    position: relative;
    z-index: 10;
    width: 100%;
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 40px;
    display: flex;
    align-items: flex-end;
    gap: 40px;
    bottom: -20px;
}

.hero-poster {
    width: 240px;
    min-width: 240px;
    border-radius: 4px;
    overflow: hidden;
    box-shadow: 0 10px 40px rgba(0,0,0,0.8);
    display: none;
}
.hero-poster img { width: 100%; height: auto; display: block; }

.meta { flex: 1; text-shadow: 2px 2px 4px rgba(0,0,0,0.8); }
.title { font-size: 3.5rem; font-weight: 800; line-height: 1.1; margin-bottom: 15px; }

.badges { display: flex; align-items: center; gap: 15px; font-weight: 600; color: #e5e5e5; font-size: 1.1rem; margin-bottom: 20px; }
.match-score { color: #46d369; }
.badge-border { border: 1px solid #999; padding: 0 6px; font-size: 0.9rem; }

.desc { max-width: 700px; color: #fff; font-size: 1.2rem; line-height: 1.5; margin-bottom: 25px; text-shadow: 1px 1px 2px rgba(0,0,0,0.8); }

.hero-buttons { display: flex; gap: 15px; margin-top: 20px; }
.btn-hero {
    display: inline-flex; align-items: center;
    padding: 10px 24px; border-radius: 4px;
    font-size: 1.1rem; font-weight: bold;
    text-decoration: none; cursor: pointer;
    transition: transform 0.2s, opacity 0.2s;
}
.btn-hero:hover { transform: scale(1.05); }
.btn-hero i { margin-right: 10px; font-size: 1.3rem; }

.btn-play { background: #fff; color: #000; }
.btn-play:hover { background: rgba(255,255,255,0.8); color: #000; }

.btn-more { background: rgba(109, 109, 110, 0.7); color: #fff; }
.btn-more:hover { background: rgba(109, 109, 110, 0.4); color: #fff; }

/* --- PLAYER SECTION --- */
.player-wrapper { padding: 40px 0; background: #000; border-top: 1px solid #333; }
.player-header { max-width: 1400px; margin: auto; display: flex; justify-content: space-between; padding: 0 40px 20px; }

.player-tabs { list-style: none; display: flex; flex-wrap: wrap; gap: 10px; max-width: 1400px; margin: 0 auto 20px; padding: 0 40px; }
.player-tabs .tab { 
    background: #222; border: 1px solid #333; 
    padding: 10px 20px; border-radius: 4px; 
    cursor: pointer; font-weight: 700; font-size: 0.9rem; 
    text-transform: uppercase; color: #aaa; transition: 0.3s;
}
.player-tabs .tab:hover { color: #fff; background: #333; }
.player-tabs .tab.selected { background: #e50914; color: #fff; border-color: #e50914; }

.player-frame { max-width: 1400px; height: 65vh; margin: auto; background: #000; position: relative; }
.player-frame iframe { width: 100%; height: 100%; border: 0; }

/* --- MODAL --- */
.tm { position: fixed; inset: 0; background: rgba(0,0,0,0.95); display: none; align-items: center; justify-content: center; z-index: 99999; padding: 20px; }
.tm.active { display: flex; }
.tm-box { position: relative; background: #000; box-shadow: 0 0 50px rgba(0,0,0,1); width: 90%; max-width: 1200px; aspect-ratio: 16 / 9; height: auto; }
.tm-close { position: absolute; top: -40px; right: 0; background: none; border: 0; color: #fff; font-size: 30px; cursor: pointer; transition: 0.2s; opacity: 0.7; }
.tm-close:hover { opacity: 1; transform: scale(1.1); }

/* --- SECTIONS --- */
.section { max-width: 1400px; margin: auto; padding: 40px; }
/* REMOVED RED BORDER LEFT HERE */
.netflix-section-title { 
    font-size: 1.5rem; 
    color: #e5e5e5; 
    margin: -20px 0 35px; 
    font-weight: 600; 
}


/* =========================================
   FIXED CSS: STRONGER SELECTORS
   Using #single ID to force override theme
========================================= */

/* --- DIRECTOR (Horizontal Card) --- */
#single #dt-director .person {
    display: flex !important;
    flex-direction: row !important;
    align-items: center !important;
    gap: 18px !important;
    background: #141414 !important;
    padding: 16px !important;
    border-radius: 12px !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
    max-width: 400px !important;
    margin-top: -12px !important;
    position: relative !important;
    width: auto !important;
    float: none !important;
}

#single #dt-director .person .img {
    width: 80px !important;
    height: 80px !important;
    border-radius: 50% !important;
    overflow: hidden !important;
    border: 2px solid #e50914 !important;
    flex-shrink: 0 !important;
    margin: 0 !important;
    position: static !important;
}
#single #dt-director .person .img img {
    width: 100% !important;
    /*height: 100% !important;*/
    object-fit: cover !important;
}

/* Director Text */
#single #dt-director .person .data {
    display: flex !important;
    flex-direction: column !important;
    justify-content: center !important;
    position: static !important;
    background: transparent !important;
    width: auto !important;
    height: auto !important;
    padding: 0 !important;
    margin: 0 !important;
    opacity: 1 !important;
}
#single #dt-director .person .name, 
#single #dt-director .person .name a {
    font-size: 1.2rem !important;
    font-weight: 700 !important;
    color: #fff !important;
    text-decoration: none !important;
    text-align: left !important;
    display: block !important;
}
#single #dt-director .person .caracter {
    font-size: 0.9rem !important;
    color: #ccc !important;
    margin-top: 2px !important;
    text-align: left !important;
    display: block !important;
}


/* --- CAST (Horizontal Strip) --- */
#dt-cast {
    display: flex !important;
    gap: 16px !important;
    overflow-x: auto !important;
    padding-bottom: 20px !important;
    scrollbar-width: thin;
    scrollbar-color: #e50914 #141414;
    white-space: nowrap !important;
    width: 100% !important;
    float: none !important;
    padding-top: 20px;
    margin-top: -35px;
}
#dt-cast::-webkit-scrollbar { height: 8px; }
#dt-cast::-webkit-scrollbar-track { background: #141414; }
#dt-cast::-webkit-scrollbar-thumb { background-color: #e50914; border-radius: 4px; }

/* Cast Card */
#single #dt-cast .person {
    background: #141414 !important;
    width: 150px !important;
    min-width: 150px !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
    border-radius: 12px !important;
    padding: 12px !important;
    text-align: center !important;
    cursor: pointer !important;
    transition: .25s !important;
    flex-shrink: 0 !important;
    position: relative !important;
    display: block !important;
    margin: 0 !important;
    float: none !important;
    height: auto !important; /* Forces container to grow with text */
}
#single #dt-cast .person:hover {
    transform: translateY(-4px);
    border-color: #e50914 !important;
}

/* Cast Avatar */
#single #dt-cast .person .img {
    width: 100% !important;
    height: 185px !important;
    overflow: hidden !important;
    border-radius: 10px !important;
    margin-bottom: 10px !important;
    position: static !important;
    opacity: 1 !important;
}
#single #dt-cast .person .img img {
    width: 100% !important;
    height: 100% !important;
    object-fit: cover !important;
}

/* Cast Text - Fixed overlap */
#single #dt-cast .person .data {
    position: static !important;
    background: transparent !important;
    width: 100% !important;
    padding: 0 !important;
    margin-top: 5px !important;
    text-align: center !important;
    height: auto !important;
    display: block !important;
    white-space: normal !important; /* Allow names to wrap */
}

#single #dt-cast .person .name, 
#single #dt-cast .person .name a {
    font-weight: 800 !important;
    font-size: 1rem !important;
    color: #fff !important;
    text-decoration: none !important;
    display: block !important;
    line-height: 1.2 !important;
}
#single #dt-cast .person .caracter {
    font-size: 0.85rem !important;
    color: #bbb !important;
    margin-top: 4px !important;
    display: block !important;
}

/* Clear floats */
.persons:after { content: ""; display: table; clear: both; }

/* --- RESPONSIVE --- */
@media (max-width: 768px) {
    .hero { height: 65vh; }
    .hero-content { flex-direction: column; align-items: center; text-align: center; padding: 0 20px; bottom: 0; }
    .hero-poster { display: none; }
    .title { font-size: 2.5rem; }
    .badges { justify-content: center; font-size: 0.9rem; }
    .desc { display: none; }
    .hero-buttons { justify-content: center; }
    .player-frame { height: 35vh; }
    
    /* Mobile Director */
    #single #dt-director .person {
        max-width: 100% !important;
        justify-content: center !important;
        text-align: center !important;
        flex-direction: column !important;
    }
    #single #dt-director .person .img {
        width: 90px !important;
        height: 90px !important;
        margin-bottom: 10px !important;
        margin-right: 0 !important;
    }
    
    /* Mobile Modal */
    .tm { align-items: center; padding: 0; }
    .tm-box { width: 100%; max-width: 100%; aspect-ratio: 16/9; }
    .tm-close { top: -45px; right: 10px; font-size: 35px; }
}

.persons {
    float: left;
    width: 100%;
    margin-bottom: 15px;
}

/* ---------------- DOWNLOAD SECTION ---------------- */
.download-section {
    margin-top: 40px;
    width: 100%;
}

/* Style the Table usually output by DooPlay */
.download-section table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 8px; /* Gap between rows */
    margin-top: 15px;
}

/* Table Header */
.download-section thead th {
    text-align: left;
    padding: 10px 20px;
    color: #777;
    font-size: 0.8rem;
    text-transform: uppercase;
    font-weight: 700;
    letter-spacing: 1px;
    border: none;
}

/* Table Rows (Cards) */
.download-section tbody tr {
    background: #1f1f1f;
    transition: transform 0.2s, background 0.2s;
}

.download-section tbody tr:hover {
    background: #2a2a2a;
    transform: translateY(-2px);
}

/* Table Cells */
.download-section td {
    padding: 15px 20px;
    color: #e5e5e5;
    font-size: 0.95rem;
    border-top: 1px solid rgba(255,255,255,0.08);
    border-bottom: 1px solid rgba(255,255,255,0.08);
    vertical-align: middle;
}

/* Rounded corners for the row "Card" effect */
.download-section td:first-child {
    border-left: 1px solid rgba(255,255,255,0.08);
    border-top-left-radius: 8px;
    border-bottom-left-radius: 8px;
    font-weight: 600;
    color: #fff;
}

.download-section td:last-child {
    border-right: 1px solid rgba(255,255,255,0.08);
    border-top-right-radius: 8px;
    border-bottom-right-radius: 8px;
    text-align: right;
}

/* Icons usually found in the table */
.download-section td i, 
.download-section td img {
    margin-right: 8px;
    opacity: 0.8;
}

/* Download Button Styling */
.download-section a.btn, 
.download-section .dload-btn, 
.download-section a[target="_blank"] {
    background: #e50914;
    color: #fff;
    padding: 8px 24px;
    border-radius: 4px;
    text-decoration: none;
    font-weight: 700;
    font-size: 0.85rem;
    display: inline-block;
    transition: 0.3s;
    text-transform: uppercase;
    border: none;
}

.download-section a.btn:hover, 
.download-section .dload-btn:hover, 
.download-section a[target="_blank"]:hover {
    background: #f40612;
    box-shadow: 0 0 15px rgba(229, 9, 20, 0.4);
    color: #fff;
}

/* Mobile Adjustments */
@media (max-width: 768px) {
    .download-section td {
        padding: 12px;
        font-size: 0.85rem;
    }
    .download-section thead {
        display: none; /* Hide headers on small screens for cleaner look */
    }
    .download-section a.btn {
        padding: 6px 12px;
        font-size: 0.75rem;
    }
}
</style>

<div id="edit_link"></div>

<div id="single" class="dtsingle" itemscope itemtype="http://schema.org/Movie">

<?php if(have_posts()): while(have_posts()): the_post(); ?>

<section class="hero" style="background-image:url('<?php echo $dynamicbg; ?>')">
    <div class="hero-content">
        
        <div class="hero-poster" style="display:block;">
            <img src="<?php echo $poster_url; ?>" alt="<?php the_title(); ?>">
        </div>

        <div class="meta">
            <h1 class="title"><?php the_title(); ?></h1>

            <div class="badges">
                <span class="match-score"><?php echo doo_isset($postmeta,'imdbRating'); ?> Match</span>
                <span><?php echo doo_isset($postmeta,'release_date'); ?></span>
                <?php if($r = doo_isset($postmeta,'runtime')) echo "<span>{$r} Min</span>"; ?>
                <?php if($d = doo_isset($postmeta,'Rated')) echo "<span class='badge-border'>{$d}</span>"; ?>
            </div>

            <div class="desc">
                <?php echo wp_trim_words(get_the_excerpt(), 45, '...'); ?>
            </div>

            <div class="hero-buttons">
                <a href="#player-wrapper" class="btn-hero btn-play">
                    <i class="fa fa-play"></i> <?php _d('Play'); ?>
                </a>
                
                <?php if(!empty($trailer_embed)): ?>
                <button class="btn-hero btn-more" id="openTrailerHero">
                    <i class="fa-solid fa-circle-info"></i> <?php _d('Trailer'); ?>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<section id="player-wrapper" class="player-wrapper">

    <div class="player-header">
        <h3 style="color:#e5e5e5; margin:0;"><i class="fa-solid fa-tv"></i> Sources</h3>
    </div>

    <ul class="player-tabs" id="player-tabs">
        <?php
        $servers = [];
        $count = 1;

        if (!empty($player) && is_array($player)):
            foreach($player as $srv):
                $label = !empty($srv['name']) ? $srv['name'] : "Server $count";
                $src = resolve_player_src($srv);
                if(!$src){ $count++; continue; }

                $servers[] = $src;
                // Print the Tab
                echo "<li class='tab' data-src='".esc_url($src)."'>$label</li>";
                $count++;
            endforeach;
        endif;

        // Trailer as a tab too
        if(!empty($trailer_embed)){
            echo "<li class='tab' data-src='".esc_url($trailer_embed)."' data-trailer='1'>Trailer</li>";
            $servers[] = $trailer_embed;
        }

        if(empty($servers)){
            echo "<li class='tab' style='cursor:default; opacity:0.5;'>No video available</li>";
        }
        ?>
    </ul>

    <div class="player-frame">
        <?php if(!empty($servers)): ?>
        <iframe id="playerFrame" src="" allow="autoplay; fullscreen" allowfullscreen></iframe>
        <?php else: ?>
            <div style="display:flex; align-items:center; justify-content:center; height:100%; color:#666;">
                <p>No video sources found.</p>
            </div>
        <?php endif; ?>
    </div>

</section>

<div class="tm" id="trailerModal">
    <div class="tm-box">
        <button class="tm-close" id="closeTrailer"><i class="fa-solid fa-xmark"></i></button>
        <?php if(!empty($trailer_embed)): ?>
        <iframe id="trailerFrame" src="" data-src="<?php echo $trailer_embed; ?>" allow="autoplay" allowfullscreen></iframe>
        <?php endif; ?>
    </div>
</div>

<div class="section">
    
    <h2 class="netflix-section-title"><?php _d('Director'); ?></h2>
    <div id="dt-director" class="persons">
        <?php doo_director(doo_isset($postmeta,'dt_dir'), "img", true); ?>
    </div>

    <h2 class="netflix-section-title"><?php _d('Cast'); ?></h2>
    <div id="dt-cast" class="persons">
        <?php doo_cast(doo_isset($postmeta,'dt_cast'), "img", true); ?>
    </div>

    <?php if(DOO_THEME_DOWNLOAD_MOD): ?>
        <?php get_template_part('inc/parts/single/links'); ?>
    <?php endif; ?>

    <?php if(DOO_THEME_RELATED): ?>
        <h2 class="netflix-section-title"><?php _d('More Like This'); ?></h2>
        <?php get_template_part('inc/parts/single/relacionados'); ?>
    <?php endif; ?>

    <div style="margin-top:40px;">
        <?php get_template_part('inc/parts/comments'); ?>
    </div>

</div>

<?php endwhile; endif; ?>

</div> <script>
document.addEventListener("DOMContentLoaded", () => {

    // --- 1. Player Tabs Logic ---
    const tabs = document.querySelectorAll("#player-tabs .tab");
    const frame = document.getElementById("playerFrame");

    if(tabs.length > 0 && frame){
        // Load first server by default
        frame.src = tabs[0].dataset.src;
        tabs[0].classList.add("selected");
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            // Remove active class from all
            tabs.forEach(t => t.classList.remove("selected"));
            // Add to clicked
            tab.classList.add("selected");
            
            // Switch Source
            if(frame) frame.src = tab.dataset.src;
        });
    });

    // --- 2. Modal Logic (Trailer) ---
    const heroTrailerBtn = document.getElementById("openTrailerHero");
    const closeTrailerBtn = document.getElementById("closeTrailer");
    const modal = document.getElementById("trailerModal");
    const trailerFrame = document.getElementById("trailerFrame");

    // Open Modal
    if(heroTrailerBtn){
        heroTrailerBtn.addEventListener("click", (e) => {
            e.preventDefault();
            modal.classList.add("active");
            if(trailerFrame) trailerFrame.src = trailerFrame.dataset.src + "?autoplay=1";
        });
    }

    // Close Modal
    if(closeTrailerBtn){
        closeTrailerBtn.addEventListener("click", () => {
            modal.classList.remove("active");
            if(trailerFrame) trailerFrame.src = ""; // Stop video
        });
    }
    
    // Close on click outside
    window.addEventListener("click", (e) => {
        if (e.target == modal) {
            modal.classList.remove("active");
            if(trailerFrame) trailerFrame.src = "";
        }
    });

});
</script>