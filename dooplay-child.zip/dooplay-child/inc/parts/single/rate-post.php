<?php
/**
 * Template part for displaying the post rating
 */

if ( function_exists( 'starstruck_post_display' ) ) {
    // This function generates the rating HTML using content.php
    echo starstruck_post_display();
}
?>